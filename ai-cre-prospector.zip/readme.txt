AI-Enhanced CRE Prospector (Basic Safe Version)
-----------------------------------------------
Shortcode: [cre_prospector]
This lightweight plugin simulates lead generation client-side and drafts outreach messages.
Features:
- Simulated leads (no external API calls)
- Fit score and outreach draft per lead
- Export CSV and printable PDF via browser
- Admin settings for disclaimer
Disclaimer: Results are AI-generated for educational use only. Always verify with experts and follow AI regulations.

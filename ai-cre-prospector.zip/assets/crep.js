document.addEventListener("DOMContentLoaded", function(){
    function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];}); }
    const genBtn = document.getElementById('crep-generate');
    const clearBtn = document.getElementById('crep-clear');
    const tbody = document.querySelector('#crep-table tbody');

    function rndChoice(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
    function makeEmail(name, company){ return name.toLowerCase().replace(/\s+/g,'.') + '@' + company.toLowerCase().replace(/\s+/g,'') + '.com'; }

    genBtn.addEventListener('click', function(){
        const property = document.getElementById('crep-property').value.trim();
        const location = document.getElementById('crep-location').value.trim();
        const intent = document.getElementById('crep-intent').value;
        const industry = document.getElementById('crep-targetIndustry').value.trim();

        if(!property || !location){ alert('Please enter property type and location'); return; }
        // simulate 5 leads
        const firstNames = ['Alex','Jordan','Taylor','Morgan','Casey','Riley','Sam','Jamie','Drew','Pat'];
        const lastNames = ['Smith','Lee','Patel','Garcia','Nguyen','Khan','Brown','Wilson','Lopez','Chen'];
        const companies = ['Arcadia','Pinnacle','Summit','Harbor','Keystone','Crescent','Atlas','Vertex','Beacon','Nexus'];

        for(let i=0;i<5;i++){
            const name = rndChoice(firstNames) + ' ' + rndChoice(lastNames);
            const company = rndChoice(companies) + (Math.floor(Math.random()*90)+10);
            // Fit score influenced by matching industry present and random factor
            let fit = Math.floor(Math.random()*41)+60; // base 60-100
            if(industry) fit = Math.min(100, fit + 10);
            // Draft outreach
            const outreach = "Hi " + name.split(' ')[0] + ",\n\nI saw your company's activities in " + (industry||"your sector") + " and thought you'd be a great fit for a " + property + " opportunity in " + location + ". Can we schedule a quick call to discuss? \n\nBest,\n[Your Name]";
            const email = makeEmail(name, company);
            const tr = document.createElement('tr');
            tr.innerHTML = '<td>'+escapeHtml(name)+'</td><td>'+escapeHtml(company)+'</td><td>'+escapeHtml(fit)+'</td><td>'+escapeHtml(email)+'</td><td><button class="crep-copy">Copy</button><pre class="crep-out" style="display:none">'+escapeHtml(outreach)+'</pre></td>';
            tbody.appendChild(tr);
        }
    });

    // delegate clicks for copy outreach
    document.querySelector('#crep-table').addEventListener('click', function(e){
        if(e.target && e.target.matches('button.crep-copy')){
            const pre = e.target.parentElement.querySelector('pre.crep-out');
            pre.style.display = pre.style.display === 'none' ? 'block' : 'none';
            // copy to clipboard
            navigator.clipboard && navigator.clipboard.writeText(pre.textContent);
            e.target.textContent = 'Copied';
            setTimeout(()=>e.target.textContent='Copy',1200);
        }
    });

    clearBtn.addEventListener('click', function(){ if(confirm('Clear leads?')) tbody.innerHTML=''; });

    document.getElementById('crep-export-csv').addEventListener('click', function(){
        const rows=[['Lead Name','Company','Fit Score','Email','Outreach']];
        document.querySelectorAll('#crep-table tbody tr').forEach(function(tr){
            const name=tr.children[0].textContent;
            const company=tr.children[1].textContent;
            const fit=tr.children[2].textContent;
            const email=tr.children[3].textContent;
            const outreach=tr.querySelector('pre.crep-out') ? tr.querySelector('pre.crep-out').textContent : '';
            rows.push([name,company,fit,email,outreach]);
        });
        if(rows.length===1){ alert('No leads to export'); return; }
        const csv = rows.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\r\n');
        const blob = new Blob([csv], {type:'text/csv'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download='cre-leads.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    });

    document.getElementById('crep-pdf').addEventListener('click', function(){
        const w = window.open('','_blank');
        let html = '<html><head><title>CRE Leads</title><style>body{font-family:Arial;padding:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px}</style></head><body>';
        html += '<h1>CRE Leads Report</h1><p>Generated: '+new Date().toLocaleString()+'</p>';
        html += '<table><thead><tr><th>Lead Name</th><th>Company</th><th>Fit</th><th>Email</th><th>Outreach</th></tr></thead><tbody>';
        document.querySelectorAll('#crep-table tbody tr').forEach(function(tr){
            html += '<tr>';
            for(let i=0;i<5;i++){
                let text = tr.children[i].textContent;
                html += '<td>'+text.replace(/</g,'&lt;')+'</td>';
            }
            html += '</tr>';
        });
        html += '</tbody></table></body></html>';
        w.document.write(html); w.document.close(); setTimeout(()=>w.print(),500);
    });

});